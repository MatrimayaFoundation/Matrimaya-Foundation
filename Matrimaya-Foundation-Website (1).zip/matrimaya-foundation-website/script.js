const toggle = document.querySelector(".menu-toggle");
const nav = document.querySelector("#primary-nav");
if (toggle && nav) {
  toggle.addEventListener("click", () => {
    const open = nav.classList.toggle("open");
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close navigation menu" : "Open navigation menu");
  });
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open navigation menu");
  }));
}
document.querySelector("#year").textContent = new Date().getFullYear();

const form = document.querySelector("#contact-form");
const note = document.querySelector("#form-note");
form.addEventListener("submit", event => {
  event.preventDefault();
  const data = new FormData(form);
  const subject = encodeURIComponent(`Matrimaya Foundation enquiry: ${data.get("topic")}`);
  const body = encodeURIComponent(
    `Name: ${data.get("name")}\nEmail: ${data.get("email")}\nTopic: ${data.get("topic")}\n\nMessage:\n${data.get("message")}`
  );
  // Replace this placeholder with the foundation's verified email address before launch.
  const officialEmail = "";
  if (!officialEmail) {
    note.textContent = "Thanks! The form is working as a demo, but an official foundation email must be added in script.js before messages can be sent.";
    return;
  }
  window.location.href = `mailto:${officialEmail}?subject=${subject}&body=${body}`;
});
