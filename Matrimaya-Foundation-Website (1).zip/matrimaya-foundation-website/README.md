# Matrimaya Foundation website

A responsive, static website starter for Matrimaya Foundation, focused on education awareness.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive design and styling
- `script.js` — mobile navigation, current year, and demo contact form

## Preview locally
Open `index.html` in a modern browser. An internet connection is used for the Google Fonts and Unsplash photographs. If offline, the page still works but external fonts/photos may not load.

## Before publishing
1. Replace draft mission and program wording with approved, accurate details.
2. Add the foundation's official email/address and verify all contact information.
3. In `script.js`, replace `const officialEmail = "";` with the official email address. The form then opens the visitor's email app; it does not submit to a server.
4. For a server-backed contact form, connect a form provider or website backend.
5. Add a privacy policy and any required legal disclosures. Include registration/tax/donation details only after verifying them.
6. Choose and register an available domain. The domain is not included or registered by this starter.

## Publish options
- **Netlify:** Sign in, choose “Add new site” / manual deploy, and upload the folder contents.
- **GitHub Pages:** Upload these files to a repository and enable Pages in repository settings.
- **Any static host:** Upload `index.html`, `styles.css`, and `script.js` to the site root.

This is a front-end starter, not a registered charity verification, donation processor, or backend.
